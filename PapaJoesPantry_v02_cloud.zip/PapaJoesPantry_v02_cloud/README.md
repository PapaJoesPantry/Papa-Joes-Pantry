# Papa Joe's Pantry v0.2

Native Android prototype for Papa Joe's Pantry.

Includes recipe storage, manual recipe creation/editing, pasted-text import, website Recipe structured-data import, photo selection/draft workflow, shopping list, and Walmart cart handoff.

## Cloud build

This repository includes `.github/workflows/build-apk.yml`. Run the workflow from GitHub Actions to compile an installable debug APK without a PC.
