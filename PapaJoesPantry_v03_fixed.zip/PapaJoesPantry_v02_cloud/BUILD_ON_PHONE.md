# Papa Joe's Pantry v0.2 — build the APK from your phone

This project includes a GitHub Actions workflow that builds the Android APK in the cloud. You do NOT need a PC or Android Studio.

## Phone-only steps

1. In Chrome, go to https://github.com and sign in (or create a free account).
2. Create a new repository named `PapaJoesPantry`.
3. Upload the contents of this folder to the repository, including the `.github` folder and all Android project files.
4. Open the repository's **Actions** tab.
5. Choose **Build Papa Joe's Pantry APK**.
6. Tap **Run workflow**.
7. Wait for the workflow to finish.
8. Open the completed workflow run and scroll to **Artifacts**.
9. Download `Papa-Joes-Pantry-v0.2-debug`.
10. Open the downloaded APK on the phone and install it. Android may ask you to allow Chrome/files to install unknown apps.

The workflow uses a cloud Linux runner, Java 17, Android SDK 35, and Gradle 8.10.2. It produces an installable debug APK.

## Important

The APK is a development/test build, not a Play Store release. We can make a signed release build later after the app's core features are finished.
